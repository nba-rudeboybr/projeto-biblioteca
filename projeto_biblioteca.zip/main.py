# main.py

import sqlite3

# Conexão com o banco
conn = sqlite3.connect('biblioteca.db')
cursor = conn.cursor()

# Criar tabelas
cursor.execute("""
CREATE TABLE IF NOT EXISTS autores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    nacionalidade TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS livros (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    ano_publicacao INTEGER,
    autor_id INTEGER,
    FOREIGN KEY (autor_id) REFERENCES autores(id)
)
""")

# Inserção de exemplo
cursor.execute("INSERT INTO autores (nome, nacionalidade) VALUES (?, ?)", ("J.K. Rowling", "Britânica"))
cursor.execute("INSERT INTO livros (titulo, ano_publicacao, autor_id) VALUES (?, ?, ?)", ("Harry Potter", 1997, 1))

# Consulta de livros com autores
cursor.execute("""
SELECT livros.titulo, livros.ano_publicacao, autores.nome 
FROM livros
JOIN autores ON livros.autor_id = autores.id
""")

print("Livros cadastrados:")
for linha in cursor.fetchall():
    print(f"{linha[0]} ({linha[1]}) - Autor: {linha[2]}")

conn.commit()
conn.close()
