-- criar_banco.sql

-- Criação das tabelas
CREATE TABLE IF NOT EXISTS autores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    nacionalidade TEXT
);

CREATE TABLE IF NOT EXISTS livros (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    ano_publicacao INTEGER,
    autor_id INTEGER,
    FOREIGN KEY (autor_id) REFERENCES autores(id)
);

-- Inserção de dados iniciais
INSERT INTO autores (nome, nacionalidade) VALUES ('Machado de Assis', 'Brasileiro');
INSERT INTO autores (nome, nacionalidade) VALUES ('George Orwell', 'Britânico');

INSERT INTO livros (titulo, ano_publicacao, autor_id) VALUES ('Dom Casmurro', 1899, 1);
INSERT INTO livros (titulo, ano_publicacao, autor_id) VALUES ('1984', 1949, 2);
